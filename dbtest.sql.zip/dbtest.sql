-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2017 at 08:50 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `ecount`
--

CREATE TABLE `ecount` (
  `eid` varchar(11) NOT NULL,
  `posted` int(10) NOT NULL DEFAULT '0',
  `shortlisted` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emplogin`
--

CREATE TABLE `emplogin` (
  `id` int(5) NOT NULL,
  `empId` varchar(11) NOT NULL,
  `empEmail` varchar(60) NOT NULL,
  `password` varchar(10) NOT NULL,
  `lastlogin` varchar(40) NOT NULL DEFAULT '00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `empregistration`
--

CREATE TABLE `empregistration` (
  `empId` varchar(11) NOT NULL,
  `fname` char(30) NOT NULL,
  `lname` char(30) NOT NULL,
  `empEmail` varchar(60) NOT NULL,
  `contactno` bigint(10) NOT NULL,
  `company` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `internshipcount`
--

CREATE TABLE `internshipcount` (
  `cid` int(5) NOT NULL,
  `empId` varchar(11) NOT NULL,
  `intId` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `postinternship`
--

CREATE TABLE `postinternship` (
  `intId` varchar(11) NOT NULL,
  `title` char(60) NOT NULL,
  `location` char(60) NOT NULL,
  `skillreq` char(100) NOT NULL,
  `position` char(30) NOT NULL,
  `stipend` varchar(10) NOT NULL,
  `descrip` longtext NOT NULL,
  `intdate` date NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scount`
--

CREATE TABLE `scount` (
  `sid` varchar(11) NOT NULL,
  `applied` int(10) NOT NULL DEFAULT '0',
  `shortlisted` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `studapplied`
--

CREATE TABLE `studapplied` (
  `appID` int(10) NOT NULL,
  `studID` varchar(11) NOT NULL,
  `intID` varchar(11) NOT NULL,
  `date` date NOT NULL,
  `status` int(1) NOT NULL,
  `shortlisted` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `studlogin`
--

CREATE TABLE `studlogin` (
  `sid` int(5) NOT NULL,
  `stId` varchar(11) NOT NULL,
  `studEmail` varchar(60) NOT NULL,
  `password` varchar(10) NOT NULL,
  `lastlogin` varchar(40) NOT NULL DEFAULT '00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `studregistration`
--

CREATE TABLE `studregistration` (
  `studId` varchar(11) NOT NULL,
  `fname` char(30) NOT NULL,
  `lname` char(30) NOT NULL,
  `studEmail` varchar(60) NOT NULL,
  `contactno` bigint(10) NOT NULL,
  `collage` char(30) NOT NULL,
  `degree` char(10) NOT NULL,
  `stream` char(10) NOT NULL,
  `skills` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ecount`
--
ALTER TABLE `ecount`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `emplogin`
--
ALTER TABLE `emplogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `empregistration`
--
ALTER TABLE `empregistration`
  ADD PRIMARY KEY (`empId`);

--
-- Indexes for table `internshipcount`
--
ALTER TABLE `internshipcount`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `postinternship`
--
ALTER TABLE `postinternship`
  ADD PRIMARY KEY (`intId`);

--
-- Indexes for table `scount`
--
ALTER TABLE `scount`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `studapplied`
--
ALTER TABLE `studapplied`
  ADD PRIMARY KEY (`appID`);

--
-- Indexes for table `studlogin`
--
ALTER TABLE `studlogin`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `studregistration`
--
ALTER TABLE `studregistration`
  ADD PRIMARY KEY (`studId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `emplogin`
--
ALTER TABLE `emplogin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `internshipcount`
--
ALTER TABLE `internshipcount`
  MODIFY `cid` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `studapplied`
--
ALTER TABLE `studapplied`
  MODIFY `appID` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `studlogin`
--
ALTER TABLE `studlogin`
  MODIFY `sid` int(5) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
