							<?php
                                include "dbcon.php";
                                global $conn;
								connectdb();
                                if(isset($_REQUEST['fetch']))
								{
								   $i=0;	
								   $eid=$_SESSION['id'];
								   $query2 = "SELECT w.studID, w.intID ,w.title, sr.fname,sr.lname,sr.studEmail,sr.contactno,sr.collage,sr.degree,sr.stream, sr.skills ,w.date
												FROM ( 
														SELECT v.studID,v.intID,pi.title,v.date , v.shortlisted
														FROM (	SELECT sa.studID , sa.intID , sa.date ,sa.shortlisted 
																FROM `internshipcount` AS ic LEFT JOIN `studapplied` AS sa 
																ON sa.intID = ic.intId WHERE ic.empId = '$eid'
															) AS v LEFT JOIN `postinternship` as pi  													
														ON v.intID = pi.intId) AS W LEFT JOIN `studregistration` AS sr
												ON w.studID = sr.studId 
												WHERE w.shortlisted = '1'
												ORDER BY w.studID";
								   $rs = executeQuery($query2);
									if (mysql_num_rows($rs) > 0)
									{		
											while($row = mysql_fetch_array($rs))
													{
														echo'<div class="col-md-11"> <div class="panel panel-default">';
														echo '<div class="panel-heading">
																<b style="font-size:22px">&raquo;'.$row['title'].'</b></div><div class="panel-body">';
														echo "<h4><label>Student Name : &nbsp;</label>" . $row['fname'] .'&nbsp;'.$row['lname']. "</h4>";
														echo "<h4><label>Email : &nbsp;</label>" . $row['studEmail'] . "</h4>";
														echo "<h4><label>Contact &nbsp; No : &nbsp;</label>" . $row['contactno'] . "</h4>";
														echo "<h4><label>Collage : &nbsp;</label>" . $row['collage'] . "</h4>";
														echo "<h4><label>Degree : &nbsp; </label>" . $row['degree'] . "</h4>";
														echo "<h4><label>Stream : &nbsp; </label>" . $row['stream'] . "</h4>";
														echo "<h4><label>Skills : &nbsp; </label>" . $row['skills'] . "</h4>";
														echo "<h4><label>Applied On : &nbsp; </label>" . $row['date'] . "</h4>";
														echo '<button class="btn btn-danger square-btn-right disabled"> &#x2713; Alraedy Shortlisted</button>';
														echo '</div></div></div>';
														$i++;
													}
														$sq="UPDATE `ecount` SET shortlisted ='$i' WHERE eid = '$eid' ";
														executeQuery($sq);
														// Close result set
														mysql_free_result($rs);
										}
										else
										{
											echo '<div class="col-md-11"> <div class="panel panel-default"><div class="panel-body">';
											echo "<h4>No Student Applied till now</h4>";
											echo "</div></div>";
										}
                                    }
                            ?>
					