<?php
session_start();
// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['id'])) {
	echo "<script>window.location.href='error.php?expiredsession';</script>";
}
?>