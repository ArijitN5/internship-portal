<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>ERROR</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />

<style type="text/css">
*{
	margin:0px;
	padding:0px;
	}
body{
	font-family:Tahoma, Geneva, sans-serif;
	}
#container{
	width:550px;
	background-color:rgba(250,250,252,.9);
	margin:auto;
	margin-top:10px;
	margin-bottom:10px;
	box-shadow:0 0 3px #999;
	}
#container_body{
	padding:20px;
	}
.form_title{
	font-size:35px;
	color:#141823;
	text-align:center;
	padding:10px;
	font-weight:normal;
	}
.head_para{
	font-size:19px;
	color:#99a2a7;
	text-align:center;
	font-weight:normal;
	}
#form_name{
	padding:25px 0 0 15px;
	}
select{
	padding:5px;
	}
</style>
</head>

<body>
<div id="description"><br><br><br><br><br></div>
<!--container start-->
<div id="container">
  <div id="container_body"><!--Form  start-->
    <div id="form_name">
        <?php 
			
			if(isset($_GET['expiredsession']))
			{ 
				echo '<div class="alert alert-danger"> <strong>Session Expired Please Login.</strong></div>';
				echo '<br>';
				echo '<a href="emphome.php"><button type="button" class="btn btn-danger btn-arrow-right">Back to Home</button></a>';
			}
			if(isset($_GET['emailexist']))
			{ 
				echo '<div class="alert alert-danger"> <strong>Email ALready Exist.</strong></div>';
				echo '<br>';
				echo '<a href="emphome.php"><button type="button" class="btn btn-danger btn-arrow-right">Back to Home</button></a>';
			}
			if(isset($_GET['error']))
			{ 
				echo '<div class="alert alert-danger"> <strong>ERROR ! Please Try again.</strong></div>';
				echo '<br>';
				echo '<a href="emphome.php"><button type="button" class="btn btn-danger btn-arrow-right">Back to Home</button></a>';
			}
			if(isset($_GET['success']))
			{
				echo '<div class="alert alert-success"> <strong>Successfully registered, you may login now.</strong> </div>';
				echo '<br>'; 
				echo '<a href="emphome.php"><button type="button" class="btn btn-success btn-arrow-left">Back to Home</button></a>';
			}
			if(isset($_GET['internshipsuccess']))
			{
				echo '<div class="alert alert-success"> <strong>Successfully posted Internship.</strong> </div>';
				echo '<br>'; 
				echo '<a href="seeposted.php?fetch"><button type="button" class="btn btn-success btn-arrow-left">View Internships</button></a>';
			}
			if(isset($_GET['loginfailed']))
			{ 
				echo '<div class="alert alert-danger"> <strong>LOGIN FAILED ! Please Try again.</strong></div>';
				echo '<br>';
				echo '<a href="emphome.php"><button type="button" class="btn btn-danger btn-arrow-right">Back to Home</button></a>';
			}
		?>
    </div>
    <!--form ends--> 
  </div>
</div>
<!--container ends-->
</body>
</html>
