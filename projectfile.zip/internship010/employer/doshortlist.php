<?php
include "dbcon.php";
global $conn;
$tbl='studapplied'; /*student applied Table */
if(isset($_GET['apply']) )
{		
		if(isset($_GET['sid']) && isset($_GET['intid']))
		{
   		    $sid = trim($_GET['sid']);
			$sid = strip_tags($sid);
			$sid = htmlspecialchars($sid);
			
			$intid = trim($_GET['intid']);
			$intid = strip_tags($intid);
			$intid = htmlspecialchars($intid);
			connectdb();
			$q = "UPDATE $tbl SET shortlisted='1' WHERE studID='$sid' AND intID='$intid' ";
			$res = executeQuery($q);
			if ($res) {
				closedb();
				echo "<script> window.location.href='seeshortlisted.php?fetch';</script>";
				unset($sid);
				unset($intid);
				unset($date);
			} 
			else 
			{
				closedb();
				echo "<script> window.location.href='error.php?error';</script>";
			}	
		}
		else echo "<script> window.location.href='error.php?expiredsession';</script>";
}
else echo "<script> window.location.href='error.php?lp';</script>";
?>