<?php
	include "dbcon.php";
	global $conn;
	$tb2 = 'empregistration'; 
	$tb3 = 'emplogin';
	$tb4 = 'ecount';
	$error = false;
	//random employer id generate
		function generateRandomString($length) {
			 $characters = 'employer9876543210';
			 $randomString = '';
			 for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, strlen($characters) - 1)];
			 }
			 return $randomString;
		}
		///end

	if ( isset($_POST['signup']) ) 
	{
		
		// clean user inputs to prevent sql injections
		$fname = trim($_POST['fname']);
		$fname = strip_tags($fname);
		$fname = htmlspecialchars($fname);
		
		$lname = trim($_POST['lname']);
		$lname = strip_tags($lname);
		$lname = htmlspecialchars($lname);
		
		$email = trim($_POST['email']);
		$email = strip_tags($email);
		$email = htmlspecialchars($email);
		
		$pass = trim($_POST['password']);
		$pass = strip_tags($pass);
		$pass = htmlspecialchars($pass);
		
		$contact = trim($_POST['contact']);
		$contact = strip_tags($contact);
		$contact = htmlspecialchars($contact);
		
		$company = trim($_POST['company']);
		$company = strip_tags($company);
		$company = htmlspecialchars($company);
		if($fname == "" && $lname =="" && $email == "" && $pass == "" && $contact == "" && $company == "" )
		{
			$error=true;
			echo "<script> window.location.href='error.php?error';</script>";
		}
		else
		{	
			
			if($email != "")
			{
				connectdb(); //db connect
				// check email exist or not
				$query = "SELECT empEmail FROM $tb2 WHERE empEmail='$email'";
				$result = executeQuery($query);
				$count =mysql_fetch_assoc($result);
				if($count!=0){
					$error = true;
					echo "<script>window.location.href='error.php?emailexist'</script>";
				}
			}
			
			// if there's no error, continue to signup
			if( !$error ) 
			{
				$eid = generateRandomString( 10 );
				$q2 = "INSERT INTO $tb2(empId,fname,lname,empEmail,contactno,company) VALUES('$eid','$fname','$lname','$email','$contact','$company')";
				$q3 = "INSERT INTO $tb3(empId,empEmail,password) VALUES('$eid','$email','$pass') ";
				$q4 = "INSERT INTO $tb4(eid) values('$eid')";
				$res = executeQuery($q2);
				$login = executeQuery($q3);
				executeQuery($q4);
					
				if ($res && $login) 
				{
					closedb();
					echo "<script> window.location.href='error.php?success';</script>";
					unset($eid);
					unset($fname);
					unset($lname);
					unset($email);
					unset($pass);
					unset($contact);
					unset($company);
				} 
				else {
						closedb();
						echo "<script> window.location.href='error.php?error';</script>";
				}
					
			}
			else
			{
						echo "<script> window.location.href='error.php?error';</script>";
			}
		}
	}
	else{
		echo "<script> window.location.href='error.php?lp';</script>";
	}
?>