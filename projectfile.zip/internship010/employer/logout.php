<?php 
	include "dbcon.php";
	global $conn;
		session_start();
		unset($_SESSION['id']);
		unset($_SESSION['uname']);
		unset($_SESSION['password']);
		if(session_destroy())
		{
			echo "<script> window.location.href='emphome.php'; </script>";
		}
?>