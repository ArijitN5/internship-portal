							<?php
                                include "dbcon.php";
                                global $conn;
                                $tbl_name='postinternship'; /*internship Table */
                                $tb='internshipcount';
                                if(isset($_REQUEST['fetch']))
								{	$p=0;
                                    connectdb();
                                    $eid=$_SESSION['id'];
                                    $query="SELECT * from `postinternship` WHERE intID IN  (SELECT `intID` FROM `internshipcount` WHERE `empId` ='$eid')";
                                    $rs=executeQuery($query);
                                    if(mysql_num_rows($rs) > 0)
                                        {
											while($row = mysql_fetch_array($rs))
											{
												echo'<div class="col-md-11"> <div class="panel panel-default">';
												echo '<div class="panel-heading"><b style="font-size:22px">&raquo;' . $row['title'] . '</b></div><div class="panel-body">';
												echo "<h4><label>Location : &nbsp;</label>" . $row['location'] . "</h4>";
												echo "<h4><label>Skills Required : &nbsp;</label>" . $row['skillreq'] . "</h4>";
												echo "<h4><label>Position : &nbsp;</label>" . $row['position'] . "</h4>";
												echo "<h4><label>Stipend : &nbsp;</label>" . $row['stipend'] . "</h4>";
												echo "<h4><label>Description : &nbsp; </label>" . $row['descrip'] . "</h4>";
												echo "<h4><label>Posted on : &nbsp; </label>" . $row['intdate'] . "</h4>";
												echo '</div></div></div>';
												$p++;
											}
												$_SESSION['pi'] = $p;
												$qr="UPDATE `ecount` SET posted ='$p' WHERE eid = '$eid'";
												executeQuery($qr);
												// Close result set
                                                mysql_free_result($rs);
												
                                        } 
                                        else
                                        {
                                                echo'<div class="col-md-11"> <div class="panel panel-default">';
                                                echo '<div class="panel-body">';
                                                echo "<h4><label>No Internship Posted. Post New one.</label></h4>";
                                                echo '</div></div></div>';
                                        }
                                    }
                            ?>
					