<style type="text/css">
	#errorBox{
	color:#F00;
	}
	#error{
		color:#F00;
	}
</style>
<script type="text/javascript">
function Submit(){
	var emailRegex = /^[A-Za-z0-9._]*\@[A-Za-z]*\.[A-Za-z]{2,5}$/;
	var fname = document.form.fname.value,
		lname = document.form.lname.value,
		femail = document.form.email.value,
		fpassword = document.form.password.value,
		fcontact = document.form.contact.value,
		fyear = document.form.company.value;
		
	if( fname == "" )
   {
     document.form.fname.focus() ;
	 document.getElementById("errorBox").innerHTML = "enter the first name";
     return false;
   }
	if( lname == "" )
   {
     document.form.lname.focus() ;
	  document.getElementById("errorBox").innerHTML = "enter the last name";
     return false;
   }
   
   if (femail == "" )
	{
		document.form.email.focus();
		document.getElementById("errorBox").innerHTML = "enter the email";
		return false;
	 }
	 else if(!emailRegex.test(femail)){
		document.form.email.focus();
		document.getElementById("errorBox").innerHTML = "enter the valid email";
		return false;
	 }
	 
	if(fpassword == "")
	 {
		 document.form.password.focus();
		 document.getElementById("errorBox").innerHTML = "enter the password";
		 return false;
	 }
	 if(fcontact == "")
	 {
		 document.form.contact.focus();
		 document.getElementById("errorBox").innerHTML = "enter contact number";
		 return false;
	 }
	 if(fcompany == "")
	 {
		 document.form.company.focus();
		 document.getElementById("errorBox").innerHTML = "enter company name";
		 return false;
	 }		  
}

function Check(){
	
	var emailRegex = /^[A-Za-z0-9._]*\@[A-Za-z]*\.[A-Za-z]{2,5}$/;
	var femail = document.form2.email.value,
		fpassword = document.form2.password.value;
	
	 if (femail == "" )
	{
		document.form2.email.focus();
		document.getElementById("error").innerHTML = "enter the email";
		return false;
	 }
	 else if(!emailRegex.test(femail)){
		document.form2.email.focus();
		document.getElementById("error").innerHTML = "enter the valid email";
		return false;
	 }
	 
	if(fpassword == "")
	 {
		 document.form2.password.focus();
		 document.getElementById("error").innerHTML = "enter the password";
		 return false;
	 }	
}
</script>
<?php
						  if((isset($_SESSION['uname'])) && !empty($_SESSION['uname'])){
							$val = $_SESSION['uname'];
						  }
						  else { 
							$val = ""; 
						  }
						  
						  if($val == "") {
							echo '
							 <a href="#" class="btn btn-danger square-btn-adjust" data-toggle="modal" data-target="#myregister">Register</a>
								<div id="myregister" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
								  <div class="modal-dialog">
								
									<!-- Modal content-->
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title"><b>Employer Registration Form</b></h4>
									  </div>
									  <div class="modal-body">
										   <form role="form"  action="register.php" name="form" method="post" onSubmit="return Submit()">
												<div class="form-group">
													<label>First Name:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder="Amal" name="fname" />
												</div>
												<div class="form-group">
													<label>Last Name:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder="Paul" name="lname" />
												</div>
												<div class="form-group">
													<label>Email-Id:</label>
													<input class="form-control" autocomplete="off" type="email" placeholder="example@gmail.com" name="email" />
												</div>
												<div class="form-group">
													<label>Password:</label>
													<input class="form-control" autocomplete="off" type="password" placeholder="Aar@N121" name="password" />
												</div>
												<div class="form-group">
													<label>Contact No.:</label>
													<input class="form-control" autocomplete="off" type="number" maxlength="10" placeholder="9832465756" name="contact" />
												</div>
												<div class="form-group">
													<label>Company Name:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder="Company INC." name="company"/>
												</div>
												<div id="errorBox"></div>
												<button type="submit" class="btn btn-default" name="signup" value="signup">Signup</button>
												<button type="reset" class="btn btn-primary" type="reset">Reset</button>
										   </form>                             
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									  </div>
									</div>
								  </div>
								</div>
							<a href="#" class="btn btn-danger square-btn-adjust" data-toggle="modal" data-target="#mylogin">Login</a>
								<div id="mylogin" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
								  <div class="modal-dialog">
								
									<!-- Modal content-->
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title"><b>Employer Login Form</b></h4>
									  </div>
									  <div class="modal-body">
										<form role="form" action="checklogin.php" method="post" name="form2" onSubmit="return Check()">
												<div class="form-group">
													<label>Email-ID:</label>
													<input class="form-control" autocomplete="off" type="email" placeholder="example@gmail.com" name="email" />
												</div>
												<div class="form-group">
													<label>Password:</label>
													<input class="form-control" autocomplete="off" type="password" placeholder="Aar@N121" name="password" />
												</div>
												<div id="error"></div> 
												<button type="submit" class="btn btn-default" name="enter">Sign In</button>
												<button type="reset" class="btn btn-primary">Reset</button>
										</form>
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									  </div>
									</div>
								
								  </div>
								</div>
							';
						  }
						  
						  else{ 
						  	echo '<div style="color:white;  float: right; font-size: 18px;">Last login :&nbsp;'.$_SESSION['llogin'].' &nbsp;&nbsp;  <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a></div>' ;
						  }

?> 