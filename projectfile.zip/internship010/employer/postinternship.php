<?php
	include "dbcon.php";
	global $conn;
	$tb2='postinternship';
	$tb3='internshipcount';
	$error = false;
	//random employer id generate
		function generateRandomString($length) {
			 $characters = 'inter9876543210nship';
			 $randomString = '';
			 for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, strlen($characters) - 1)];
			 }
			 return $randomString;
		}
		///end

	if ( isset($_POST['post']) ) 
	{
		
		// clean user inputs to prevent sql injections
		$title = trim($_POST['it']);
		$title = strip_tags($title);
		$title = htmlspecialchars($title);
		
		$location = trim($_POST['il']);
		$location = strip_tags($location);
		$location = htmlspecialchars($location);
		
		$skill = trim($_POST['sr']);
		$skill = strip_tags($skill);
		$skill = htmlspecialchars($skill);
		
		$position = trim($_POST['ip']);
		$position = strip_tags($position);
		$position = htmlspecialchars($position);
		
		$stipend = trim($_POST['is']);
		$stipend = strip_tags($stipend);
		$stipend = htmlspecialchars($stipend);
		
		$descrip = trim($_POST['descrip']);
		$descrip = strip_tags($descrip);
		$descrip = htmlspecialchars($descrip);
		
		$timestamp = time();
		$date=date("Y/m/d",$timestamp);
		if($title == "" && $location =="" && $skill == "" && $position == "" && $stipend == "" && $descrip == "" )
		{
			$error=true;
			echo "<script> window.location.href='error.php?error';</script>";
		}
		else
		{			
			connectdb(); //db connect
			
			// if there's no error, continue to post internship
			if( !$error ) {
				$intid = generateRandomString( 10 );
				session_start();
				$eid=$_SESSION['id'];
				$q2 = "INSERT INTO $tb2(intId,title,location,skillreq,position,stipend,descrip,intdate,status)
							VALUES('$intid','$title','$location','$skill','$position','$stipend','$descrip','$date','1')";
				$q3= "INSERT INTO $tb3(empId,intId) VALUES('$eid','$intid')";
				$res = executeQuery($q2);
				$res2 = executeQuery($q3);
					
				if ($res && $res2) 
				{
					closedb();
					echo "<script> window.location.href='error.php?internshipsuccess';</script>";
					unset($eid);
					unset($intid);
					unset($title);
					unset($location);
					unset($skill);
					unset($position);
					unset($cstipend);
					unset($descrip);
					unset($date);
				} 
				else {
							closedb();
							echo "<script> window.location.href='error.php?error';</script>";
					}
						
				}
				else
				{
							echo "<script> window.location.href='error.php?error';</script>";
				}
			}
	}
	else{
		echo "<script> window.location.href='error.php?lp';</script>";
	}
?>