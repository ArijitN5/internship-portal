<?php
	include "dbcon.php";
	global $conn;
	$tbl_name='emplogin'; /*employer Login Table */
	$table2='empregistration';
	$table3='internshipcount';
	date_default_timezone_set("Asia/Kolkata");
	$d=date("F d, Y h:i:s A");
	if(isset($_REQUEST['enter'])){
		// username and password sent from form 
		$myusername=$_POST['email']; 
		$mypassword=$_POST['password']; 

		// To protect MySQL injection (more detail about MySQL injection)
		$myusername = stripslashes($myusername);
		$mypassword = stripslashes($mypassword);
		$myusername = mysql_real_escape_string($myusername);
		$mypassword = mysql_real_escape_string($mypassword);
		connectdb();
		$query="SELECT empId,empEmail,password from $tbl_name";
		$rs=executeQuery($query);
		while($arr=mysql_fetch_assoc($rs)){
			if($arr['empEmail']==$myusername and $arr['password']==$mypassword){
				session_start();
				$e = $_SESSION['id'] = $arr['empId'];
				$query2 = "SELECT fname, lname from $table2 WHERE empID = '$e' ";
				$query3 = "SELECT posted , shortlisted FROM ecount WHERE eid = '$e' ";
				$query4 = "UPDATE $tbl_name SET lastlogin = '$d' WHERE empId = '$e' ";
				$rs2 = executeQuery($query2);
				$rs3 = executeQuery($query3);
				$rs4 = executeQuery($query4);
				$row = mysql_fetch_assoc($rs3);
				$_SESSION['pi'] = $row['posted'];
				$_SESSION['sl'] = $row['shortlisted'];
				$_SESSION['llogin']=$d;
				while($arr2=mysql_fetch_assoc($rs2)){
					$_SESSION['uname']=$arr2['fname'].'&nbsp;'.$arr2['lname'];
				}
				header('Location: emphome.php');
			}
			else{
				echo "<script> window.location.href='error.php?loginfailed';</script>";
			}
		}
	}	
?>