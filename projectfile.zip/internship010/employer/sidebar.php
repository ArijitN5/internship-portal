<style type="text/css">
	#errorBox{
	   color:#F00;
	}
</style>
<script src="assets/js/jquery-1.10.2.js"></script>
<script type="text/javascript">
function Validate(){
	var title = document.form3.it.value,
		location = document.form3.il.value,
		skill = document.form3.sr.value,
		position = document.form3.ip.value,
		stipend = document.form3.is.value,
		descrip = document.form3.descrip.value;
		
	if( title == "" )
   {
     document.form3.it.focus() ;
	 document.getElementById("errorBox").innerHTML = "Internship Title required.";
     return false;
   }
	if( location == "" )
   {
     document.form3.il.focus() ;
	  document.getElementById("errorBox").innerHTML = "Internship Location required.";
     return false;
   }
   
   if (skill == "" )
	{
		document.form3.sr.focus();
		document.getElementById("errorBox").innerHTML = "Internship Skill required.";
		return false;
	 }
	if(position == "")
	 {
		 document.form3.ip.focus();
		 document.getElementById("errorBox").innerHTML = "Internship Position required.";
		 return false;
	 }
	 if(stipend == "")
	 {
		 document.form3.is.focus();
		 document.getElementById("errorBox").innerHTML = "Internship Stipend required.";
		 return false;
	 }
	 if(descrip == "")
	 {
		 document.form3.descrip.focus();
		 document.getElementById("errorBox").innerHTML = "Internship Description required.";
		 return false;
	 }		  
}
$(document).on("paste keydown", ".form-control", function (e) {
			var $this = $(this);
			var max = 500;
			setTimeout(function () {
				var text = $this.val();
				if (text.length >= max) {
					e.preventDefault();
					$this.val(text.substring(0, max));
					document.getElementById('errorBox').innerHTML = "Alert ! exceeds 500 characters in textarea.";
				} else {
					document.getElementById('errorBox').innerHTML = "";
				}
			}, 100);
		});
</script>
<div id="postinternship" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static" >
	<div class="modal-dialog">
    <!-- Modal content-->
		<div class="modal-content">
			  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><b>Post New Internship Form</b></h4>
			  </div>
			  <div class="modal-body">
				   <form role="form"  action="postinternship.php" name="form3" method="post" onSubmit="return Validate()">
						<div class="form-group">
							<label>Internship Title:</label>
							<input class="form-control" autocomplete="off" type="text" placeholder="Web Developer in ANOTHER COMPANY" name="it" />
						</div>
                        <div class="form-group">
							<label>Internship Location:</label>
							<input class="form-control" autocomplete="off" type="text" placeholder="KOLKATA/ WORK FROM HOME etc" name="il" />
						</div>
                        <div class="form-group">
							<label>Skills Required:</label>
							<input class="form-control" autocomplete="off" type="text" placeholder="PHP, PYTHON,JQUERY etc" name="sr" />
						</div>
                        <div class="form-group">
							<label>Internship Post:</label>
							<input class="form-control" autocomplete="off" type="text" placeholder="Developer/Research Assistant etc" name="ip" />
						</div>
                        <div class="form-group">
							<label>Internship Stipend:</label>
							<input class="form-control" autocomplete="off" type="text" placeholder="paid 3000 per month /unpaid" name="is" />
						</div>
                        <div class="form-group">
							<label>Internship Description:[max :500 characters]</label>
                            <textarea class="form-control" autocomplete="off" placeholder="Write something about internship." name="descrip"></textarea>
						</div>
						<div id="errorBox"></div>
						<button type="submit" class="btn btn-default" name="post" value="post">Post</button>
						<button type="reset" class="btn btn-primary" type="reset">Reset</button>
				   </form>                             
			  </div>
			  <div class="modal-footer">
		     	   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			  </div>
	   </div>
	</div>
</div>
<?php
if((isset($_SESSION['uname'])) && !empty($_SESSION['uname'])){
   $val = $_SESSION['uname'];
}
else { 
   $val = ""; 
}
if($val == "") {
   echo ' <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
               <ul class="nav" id="main-menu"> 
			   		<li class="text-center">
                        <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>                  
                    <li>
                        <a class="active-menu"  href="../home.php"><i class="fa fa-dashboard fa-3x"></i>HOME</a>
                    </li>                                	
                </ul> 
            </div> 
        </nav>	
    ';
}
else {
   echo '
   		<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
               <ul class="nav" id="main-menu">
                    <li class="text-center">
                        <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>                   
                    <li>
                        <a class="active-menu"  href="emphome.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>                                
                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i>About Internship<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#postinternship">Post New Internship</a>
                                </li>
                                <li>
                                    <a href="seeposted.php?fetch">See Posted Internships</a>
                                </li>
								<li>
                                    <a href="seeapplied.php?fetch">Applied Students</a>
                                </li>
								<li>
                                    <a href="seeshortlisted.php?fetch">Shortlisted Students</a>
                                </li>
                         </ul>
                     </li>  	
                </ul> 
            </div> 
        </nav>
   ' ;
}
          
?>