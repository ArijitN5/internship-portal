					<h1>
						<a href="home.php">
							<img src="images/internship-logo.png" alt="Your Happy Family">
						</a>
					</h1>
					<div class="menu_block">
						<nav class="horizontal-nav full-width horizontalNav-notprocessed">
							<ul class="sf-menu">
								<li class="current"><a href="home.php">Home</a></li>
								<li><a href="../internship010/student/studenthome.php">Student</a></li>
								<li><a href="../internship010/employer/emphome.php">Employer</a></li>
								<li><a href="#">About Us</a></li>
								<li><a href="contact.php">Contact us</a></li>
							</ul>
						</nav>
						<div class="clear"></div>
					</div>