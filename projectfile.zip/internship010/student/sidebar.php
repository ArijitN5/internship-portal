<?php
if((isset($_SESSION['uname'])) && !empty($_SESSION['uname'])){
   $val = $_SESSION['uname'];
}
else { 
   $val = ""; 
}
if($val == "") {
   echo ' <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
               <ul class="nav" id="main-menu"> 
			   		<li class="text-center">
                        <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>                  
                    <li>
                        <a class="active-menu"  href="../home.php"><i class="fa fa-dashboard fa-3x"></i>HOME</a>
                    </li>                                	
                </ul> 
            </div> 
        </nav>	
    ';
}
else {
   echo '
   		<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
               <ul class="nav" id="main-menu">
                    <li class="text-center">
                        <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>                   
                    <li>
                        <a class="active-menu"  href="studenthome.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>                                
                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i>About Internship<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
								<li>
                                    <a href="seeinternship.php?fetch">New Internships</a>
                                </li>
                                <li>
                                    <a href="appliedinternship.php?fetch">Applied Internships</a>
                                </li>
								<li>
                                    <a href="seeshortlisted.php?fetch">Shortlisted</a>
                                </li>
                         </ul>
                     </li>  	
                </ul> 
            </div> 
        </nav>
   ' ;
}
          
?>