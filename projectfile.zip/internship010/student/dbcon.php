<?php
	function connectdb()
	{
		$dbserver="localhost";
		$dbusername="root";
		$dbpassword="";
		$dbname="dbtest";
		if (!($conn = @mysql_connect ($dbserver,$dbusername,$dbpassword)))
			 echo "Cannot connect to server";
		
		if (!@mysql_select_db ($dbname))
			 echo "Cannot select database";
	}
	
	function executeQuery($query)
	{
		$result=mysql_query($query);
		if(!$result)
			echo "Error while executing query.<br/>Mysql Error: ".mysql_error();
		else
			return $result;
	
	}
	
	function closedb()
	{
			mysql_close();
	}

?>