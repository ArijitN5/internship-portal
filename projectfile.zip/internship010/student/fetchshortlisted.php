							<?php
                                include "dbcon.php";
                                global $conn;
								connectdb();
                                if(isset($_REQUEST['fetch']))
								{
								   $i=0;	
								   $sid=$_SESSION['id'];
								   $query = " SELECT title
								   				FROM `postinternship`
												WHERE intId IN( SELECT intID
																FROM `studapplied`
																WHERE studID = '$sid' AND shortlisted = '1' ) ";
								   $rs = executeQuery($query);
									if (mysql_num_rows($rs) == 0)
									{	
											echo '<div class="col-md-11"> <div class="panel panel-default"><div class="panel-body">';
											echo "<h4>Not selected in Internship till now.</h4>";
											echo "</div></div>";	
											
										}
										else
										{
											
											
											while($row = mysql_fetch_array($rs))
													{
														echo'<div class="col-md-11"> <div class="panel panel-default">';
														echo '<div class="panel-heading">
																<b style="font-size:22px">&raquo;Internship Title'.$row['title'].'</b></div><div class="panel-body">';
														echo '<button class="btn btn-success square-btn-right disabled"> &#x2713; Shortlisted for This Internship</button>';
														echo '</div></div></div>';
														$i++;
													}
														$_SESSION['sl'] = $i;
														$sq="UPDATE `scount` SET shortlisted ='$i' WHERE sid = '$sid' ";
														executeQuery($sq);
														// Close result set
														
														mysql_free_result($rs);
										}
                                    }
                            ?>
					