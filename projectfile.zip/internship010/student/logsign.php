<style type="text/css">
	#errorBox{
	color:#F00;
	}
	#error{
		color:#F00;
	}
</style>
<script src="assets/js/jquery-1.10.2.js"></script>
<script type="text/javascript">
function S(){
	var emailRegex = /^[A-Za-z0-9._]*\@[A-Za-z]*\.[A-Za-z]{2,5}$/;
	var fname = document.form5.fname.value,
		lname = document.form5.lname.value,
		femail = document.form5.email.value,
		fpassword = document.form5.password.value,
		fcontact = document.form5.contact.value,
		fcollage = document.form5.collage.value;
		fdegree = document.form5.degree.value;
		fstream = document.form5.stream.value;
		fskills = document.form5.skills.value;
		
	if( fname == "" )
   {
     document.form5.fname.focus() ;
	 document.getElementById("errorBox").innerHTML = "enter the first name";
     return false;
   }
	if( lname == "" )
   {
     document.form5.lname.focus() ;
	  document.getElementById("errorBox").innerHTML = "enter the last name";
     return false;
   }
   
   if (femail == "" )
	{
		document.form5.email.focus();
		document.getElementById("errorBox").innerHTML = "enter the email";
		return false;
	 }
	 else if(!emailRegex.test(femail)){
		document.form5.email.focus();
		document.getElementById("errorBox").innerHTML = "enter the valid email";
		return false;
	 }
	 
	if(fpassword == "")
	 {
		 document.form5.password.focus();
		 document.getElementById("errorBox").innerHTML = "enter the password";
		 return false;
	 }
	 if(fcontact == "")
	 {
		 document.form5.contact.focus();
		 document.getElementById("errorBox").innerHTML = "enter contact number";
		 return false;
	 }
	 if(fcollage == "")
	 {
		 document.form5.focus();
		 document.getElementById("errorBox").innerHTML = "enter collage name";
		 return false;
	 }
	  if(fdegree == "")
	 {
		 document.form5.focus();
		 document.getElementById("errorBox").innerHTML = "enter degree name";
		 return false;
	 }
	  if(fstream == "")
	 {
		 document.form5.focus();
		 document.getElementById("errorBox").innerHTML = "enter stream name";
		 return false;
	 }
	  if(fskills == "")
	 {
		 document.form5.focus();
		 document.getElementById("errorBox").innerHTML = "enter skills you have";
		 return false;
	 }		  
}

function Check(){
	
	var emailRegex = /^[A-Za-z0-9._]*\@[A-Za-z]*\.[A-Za-z]{2,5}$/;
	var femail = document.form2.email.value,
		fpassword = document.form2.password.value;
	
	 if (femail == "" )
	{
		document.form2.email.focus();
		document.getElementById("error").innerHTML = "enter the email";
		return false;
	 }
	 else if(!emailRegex.test(femail)){
		document.form2.email.focus();
		document.getElementById("error").innerHTML = "enter the valid email";
		return false;
	 }
	 
	if(fpassword == "")
	 {
		 document.form2.password.focus();
		 document.getElementById("error").innerHTML = "enter the password";
		 return false;
	 }	
}

$(document).on("paste keydown", ".form-control", function (e) {
			var $this = $(this);
			var max = 100;
			setTimeout(function () {
				var text = $this.val();
				if (text.length >= max) {
					e.preventDefault();
					$this.val(text.substring(0, max));
					document.getElementById('errorBox').innerHTML = "Alert ! exceeds 100 characters in textarea.";
				} else {
					document.getElementById('errorBox').innerHTML = "";
				}
			}, 100);
		});
</script>
<?php
						  if((isset($_SESSION['uname'])) && !empty($_SESSION['uname'])){
							$val = $_SESSION['uname'];
						  }
						  else { 
							$val = ""; 
						  }
						  
						  if($val == "") {
							echo '
							 <a href="#" class="btn btn-danger square-btn-adjust" data-toggle="modal" data-target="#myregister">Register</a>
								<div id="myregister" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
								  <div class="modal-dialog">
								
									<!-- Modal content-->
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title"><b>Student Registration Form</b></h4>
									  </div>
									  <div class="modal-body">
										   <form role="form"  action="studreg.php" name="form5" method="post" onSubmit="return S()">
												<div class="form-group">
													<label>First Name:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder="Amal" name="fname" />
												</div>
												<div class="form-group">
													<label>Last Name:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder="Paul" name="lname" />
												</div>
												<div class="form-group">
													<label>Email-Id:</label>
													<input class="form-control" autocomplete="off" type="email" placeholder="example@gmail.com" name="email" />
												</div>
												<div class="form-group">
													<label>Password:</label>
													<input class="form-control" autocomplete="off" type="password" placeholder="Aar@N121" name="password" />
												</div>
												<div class="form-group">
													<label>Contact No.:</label>
													<input class="form-control" autocomplete="off" type="number" maxlength="10" placeholder="9832465756" name="contact" />
												</div>
												<div class="form-group">
													<label>Collage:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder=" IIT-B/IIT-kgp/VIT etc." name="collage"/>
												</div>
												<div class="form-group">
													<label>Degree:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder="B.Tech/M.Tech etc." name="degree"/>
												</div>
												<div class="form-group">
													<label>Stream:</label>
													<input class="form-control" autocomplete="off" type="text" placeholder="IT/CSE/EE etc." name="stream"/>
												</div>
												<div class="form-group">
													<label>Skills:[max :100 characters]</label>
													<textarea class="form-control" autocomplete="off" placeholder="CEH/PHP/PYTHON etc" name="skills"></textarea>
												</div>
												<div id="errorBox"></div>
												<button type="submit" class="btn btn-default" name="signup" value="signup">Signup</button>
												<button type="reset" class="btn btn-primary" type="reset">Reset</button>
										   </form>                             
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									  </div>
									</div>
								  </div>
								</div>
							<a href="#" class="btn btn-danger square-btn-adjust" data-toggle="modal" data-target="#mylogin">Login</a>
								<div id="mylogin" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
								  <div class="modal-dialog">
								
									<!-- Modal content-->
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title"><b>Employer Login Form</b></h4>
									  </div>
									  <div class="modal-body">
										<form role="form" action="checklogin.php" method="post" name="form2" onSubmit="return Check()">
												<div class="form-group">
													<label>Email-ID:</label>
													<input class="form-control" autocomplete="off" type="email" placeholder="example@gmail.com" name="email" />
												</div>
												<div class="form-group">
													<label>Password:</label>
													<input class="form-control" autocomplete="off" type="password" placeholder="Aar@N121" name="password" />
												</div>
												<div id="error"></div> 
												<button type="submit" class="btn btn-default" name="enter">Sign In</button>
												<button type="reset" class="btn btn-primary">Reset</button>
										</form>
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									  </div>
									</div>
								
								  </div>
								</div>
							';
						  }
						  
						  else{ 
						  	echo '<div style="color:white;  float: right; font-size: 18px;">Last login :&nbsp;'.$_SESSION['llogin'].' &nbsp;&nbsp;  <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a></div>' ;
						  }

?> 