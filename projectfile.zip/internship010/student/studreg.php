<?php
	include "dbcon.php";
	global $conn;
	$tb2='studregistration'; 
	$tb3='studlogin';
	$tb4 = 'scount';
	$error = false;
	//random employer id generate
		function generateRandomString($length) {
			 $characters = 'student9876543210';
			 $randomString = '';
			 for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, strlen($characters) - 1)];
			 }
			 return $randomString;
		}
		///end

	if ( isset($_POST['signup']) ) 
	{
		// clean user inputs to prevent sql injections
		$fname = trim($_POST['fname']);
		$fname = strip_tags($fname);
		$fname = htmlspecialchars($fname);
		
		$lname = trim($_POST['lname']);
		$lname = strip_tags($lname);
		$lname = htmlspecialchars($lname);
		
		$email = trim($_POST['email']);
		$email = strip_tags($email);
		$email = htmlspecialchars($email);
		
		$pass = trim($_POST['password']);
		$pass = strip_tags($pass);
		$pass = htmlspecialchars($pass);
		
		$contact = trim($_POST['contact']);
		$contact = strip_tags($contact);
		$contact = htmlspecialchars($contact);
		
		$collage = trim($_POST['collage']);
		$collage = strip_tags($collage);
		$collage = htmlspecialchars($collage);
		
		$degree = trim($_POST['degree']);
		$degree = strip_tags($degree);
		$degree = htmlspecialchars($degree);
		
		$stream = trim($_POST['stream']);
		$stream = strip_tags($stream);
		$stream = htmlspecialchars($stream);
		
		$skills = trim($_POST['skills']);
		$skills = strip_tags($skills);
		$skills = htmlspecialchars($skills);
		if($fname == "" && $lname =="" && $email == "" && $pass == "" && $contact == "" && $collage == "" && $degree =="" && $stream == "" && $skills == "" )
		{
			$error=true;
			echo "<script> window.location.href='error.php?error';</script>";
		}
		else
		{
				connectdb(); //db connect
				if($email != "")
				{
					// check email exist or not
					$query = "SELECT studEmail FROM $tb2 WHERE studEmail='$email'";
					$result = executeQuery($query);
					$count =mysql_fetch_assoc($result);
					if($count!=0){
						$error = true;
						echo "<script>window.location.href='error.php?emailexist'</script>";
					}
				}
				
				// if there's no error, continue to signup
				if( !$error ) 
				{
					$id = generateRandomString( 10);
					$q2 = "INSERT INTO $tb2(studId,fname,lname,studEmail,contactno,collage,degree,stream,skills)    
					        VALUES('$id','$fname','$lname','$email','$contact','$collage','$degree','$stream','$skills')";
					$q3 = "INSERT INTO $tb3(stId,studEmail,password) VALUES('$id','$email','$pass') ";
					$q4 = "INSERT INTO $tb4(sid) values('$id')";
					$res = executeQuery($q2);
					$login = executeQuery($q3);
					executeQuery($q4);
						
					if ($res && $login) {
						closedb();
						echo "<script> window.location.href='error.php?success';</script>";
						unset($eid);
						unset($fname);
						unset($lname);
						unset($email);
						unset($pass);
						unset($contact);
						unset($collage);
						unset($degree );
						unset($stream);
						unset($skills);
					} 
					else 
					{
							closedb();
							echo "<script> window.location.href='error.php?error';</script>";
					}	
				}
				else
				{
						echo "<script> window.location.href='error.php?error';</script>";
				}
		}
	}
	else{
		echo "<script> window.location.href='error.php?lp';</script>";
	}
?>