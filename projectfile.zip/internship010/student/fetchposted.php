<?php
    include "dbcon.php";
    global $conn;
    $tbl_name='postinternship'; /*internship Table */
	$tbl2='studapplied';
    if(isset($_REQUEST['fetch'])){
        connectdb();
        $id = $_SESSION['id'];
        $query = "SELECT * from $tbl_name ";
		$query2 =  "SELECT DISTINCT ip.intId, ip.title , ip.location , ip.skillreq ,ip.position,ip.stipend,ip.descrip,ip.intdate 
				 	FROM `studapplied` AS ap , `postinternship` AS ip 
					WHERE ip.intId IN(SELECT intID from `studapplied` WHERE studID = '$id' && status = '1')";
		
		$query3 = "SELECT DISTINCT ip.intId, ip.title , ip.location , ip.skillreq ,ip.position,ip.stipend,ip.descrip,ip.intdate 
					FROM `studapplied` AS ap , `postinternship` AS ip 
					WHERE ip.intId NOT IN(SELECT intID from `studapplied` WHERE studID = '$id' && status = '1')";
	
		$rs = executeQuery($query);
		$rs2 = executeQuery($query2);
		$rs3 = executeQuery($query3);
		if(mysql_num_rows($rs) > 0) //internship available
		{	 
				if(mysql_num_rows($rs2) == 0) //No internship applied by student yet
				{ 
					while($row = mysql_fetch_array($rs))
					 {
							echo'<div class="col-md-11"> <div class="panel panel-default">';
							echo '<div class="panel-heading"><b style="font-size:22px">&raquo;' . $row['title'] . '</b></div><div class="panel-body">';
							echo "<h4><label>Location : &nbsp;</label>" . $row['location'] . "</h4>";
							echo "<h4><label>Skills Required : &nbsp;</label>" . $row['skillreq'] . "</h4>";
							echo "<h4><label>Position : &nbsp;</label>" . $row['position'] . "</h4>";
							echo "<h4><label>Stipend : &nbsp;</label>" . $row['stipend'] . "</h4>";
							echo "<h4><label>Description : &nbsp; </label>" . $row['descrip'] . "</h4>";
							echo "<h4><label>Posted on : &nbsp; </label>" . $row['intdate'] . "</h4>";
							echo '<a class="btn btn-success square-btn-right" href="apply.php?apply&&sid='.$id.'&&intid='.$row['intId'].'">Apply Internship</a>';
							echo '</div></div></div>';
					 }
				}
				else
				{
					 while($row3 = mysql_fetch_array($rs3))
					 {
							echo'<div class="col-md-11"> <div class="panel panel-default">';
							echo '<div class="panel-heading"><b style="font-size:22px">&raquo;' . $row3['title'] . '</b></div><div class="panel-body">';
							echo "<h4><label>Location : &nbsp;</label>" . $row3['location'] . "</h4>";
							echo "<h4><label>Skills Required : &nbsp;</label>" . $row3['skillreq'] . "</h4>";
							echo "<h4><label>Position : &nbsp;</label>" . $row3['position'] . "</h4>";
							echo "<h4><label>Stipend : &nbsp;</label>" . $row3['stipend'] . "</h4>";
							echo "<h4><label>Description : &nbsp; </label>" . $row3['descrip'] . "</h4>";
							echo "<h4><label>Posted on : &nbsp; </label>" . $row3['intdate'] . "</h4>";
							echo '<a class="btn btn-success square-btn-right" href="apply.php?apply&&sid='.$id.'&&intid='.$row3['intId'].'">Apply Internship</a>';
							//echo '<div style="color:green;  float:right; font-size: 18px;" id="success_para"><!--message after applied internship--></div>';
							echo '</div></div></div>';
					 }
				}
		}
		else
		{
			echo'<div class="col-md-11"> <div class="panel panel-default"><div class="panel-body">';
			echo '<h4 style="color:red;">No internship available.</h4>';
			echo '</div></div></div>';
		}
	}
	else echo "<script> window.location.href='error.php?error';</script>";
?>
					