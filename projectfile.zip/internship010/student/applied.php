<?php
    include "dbcon.php";
    global $conn;
    $tbl_name='postinternship'; /*internship Table */
	$tbl2='studapplied';
    if(isset($_REQUEST['fetch'])){
        connectdb();
		$p=0;
        $id = $_SESSION['id'];
        $query = "SELECT * from $tbl_name ";
		$query2 =  "SELECT DISTINCT ip.intId, ip.title , ip.location , ip.skillreq ,ip.position,ip.stipend,ip.descrip,ip.intdate 
				 	FROM `studapplied` AS ap , `postinternship` AS ip 
					WHERE ip.intId IN(SELECT intID from `studapplied` WHERE studID = '$id' && status = '1')";
	
		$rs = executeQuery($query);
		$rs2 = executeQuery($query2);
		if(mysql_num_rows($rs) > 0) //internship available
		{	 
				if(mysql_num_rows($rs2) == 0) //No internship applied by student yet
				{ 
							echo'<div class="col-md-11"> <div class="panel panel-default"><div class="panel-body">';
							echo '<h4>No internship applied till now.</h4>';
							echo '</div></div></div>';
				}
				else
				{
					 while($row2 = mysql_fetch_array($rs2))
					 {
							echo'<div class="col-md-11"> <div class="panel panel-default">';
							echo '<div class="panel-heading"><b style="font-size:22px">&raquo;' .$row2['title'] . '</b></div><div class="panel-body">';
							echo "<h4><label>Location : &nbsp;</label>" . $row2['location'] . "</h4>";
							echo "<h4><label>Skills Required : &nbsp;</label>" . $row2['skillreq'] . "</h4>";
							echo "<h4><label>Position : &nbsp;</label>" . $row2['position'] . "</h4>";
							echo "<h4><label>Stipend : &nbsp;</label>" . $row2['stipend'] . "</h4>";
							echo "<h4><label>Description : &nbsp; </label>" . $row2['descrip'] . "</h4>";
							echo "<h4><label>Posted on : &nbsp; </label>" . $row2['intdate'] . "</h4>";
							echo '<button class="btn btn-danger square-btn-right disabled"> &#x2713; Alraedy Applied </button>';
							echo '</div></div></div>';
							$p++;
					 }
					  $_SESSION['ap'] = $p;
					 $sq="UPDATE `scount` SET applied ='$p' WHERE sid = '$id' ";
					  executeQuery($sq);
				}
		}
		else
		{
			echo'<div class="col-md-11"> <div class="panel panel-default"><div class="panel-body">';
			echo '<h4 style="color:red;">No internship available.</h4>';
			echo '</div></div></div>';
		}
	}
	else echo "<script> window.location.href='error.php?error';</script>";
?>
					